
// app.js
const express = require("express");
const bodyParser = require("body-parser");
const jwt = require("jsonwebtoken");
const fs = require("fs");
const cors = require("cors");
const axios = require("axios");
const cron = require("node-cron");
require("dotenv").config();

const app = express();
app.use(bodyParser.json());
app.use(cors());

// ---------------- Config ----------------
const PORT = process.env.PORT || 4000;
const JWT_SECRET = process.env.JWT_SECRET || "supersecret";
const dbFile = "./db.json";

function loadDB() {
  if (!fs.existsSync(dbFile)) {
    return { users: [], deposits: [], withdrawals: [], transactions: [] };
  }
  return JSON.parse(fs.readFileSync(dbFile));
}
function saveDB(data) {
  fs.writeFileSync(dbFile, JSON.stringify(data, null, 2));
}
let db = loadDB();

// ---------------- Helpers ----------------
function generateId(prefix) {
  return prefix + "_" + Math.random().toString(36).substr(2, 9);
}
function auth(req, res, next) {
  const token = req.headers["authorization"];
  if (!token) return res.status(401).json({ error: "No token" });
  try {
    const decoded = jwt.verify(token.split(" ")[1], JWT_SECRET);
    req.user = decoded;
    next();
  } catch {
    res.status(401).json({ error: "Invalid token" });
  }
}
function sendSMS(to, message) {
  if (process.env.AT_API_KEY && process.env.AT_USERNAME) {
    console.log(`(Real SMS via Africa's Talking would go to ${to}: ${message})`);
  } else {
    console.log(`SMS (not sent) -> ${to}: ${message}`);
  }
}
function mpBase() {
  return process.env.MPESA_ENV === "production"
    ? "https://api.safaricom.co.ke"
    : "https://sandbox.safaricom.co.ke";
}
async function getMpesaToken() {
  const url = `${mpBase()}/oauth/v1/generate?grant_type=client_credentials`;
  const auth = Buffer.from(
    `${process.env.MPESA_CONSUMER_KEY}:${process.env.MPESA_CONSUMER_SECRET}`
  ).toString("base64");
  const { data } = await require("axios").get(url, {
    headers: { Authorization: `Basic ${auth}` },
  });
  return data.access_token;
}

// ---------------- Auth ----------------
app.post("/signup", (req, res) => {
  const { phone, password, referral } = req.body;
  if (db.users.find((u) => u.phone === phone)) {
    return res.status(400).json({ error: "User exists" });
  }
  const user = {
    id: generateId("u"),
    phone,
    password,
    balance: 0,
    referral,
    investments: [],
    created: Date.now(),
  };
  db.users.push(user);
  saveDB(db);
  const token = jwt.sign({ id: user.id }, JWT_SECRET, { expiresIn: "7d" });
  res.json({ token });
});

app.post("/login", (req, res) => {
  const { phone, password } = req.body;
  const user = db.users.find((u) => u.phone === phone && u.password === password);
  if (!user) return res.status(400).json({ error: "Invalid" });
  const token = jwt.sign({ id: user.id }, JWT_SECRET, { expiresIn: "7d" });
  res.json({ token });
});

// ---------------- Investments ----------------
const products = [
  { id: "p8", name: "iPhone 8", price: 2300, daily: 146, days: 16 },
  { id: "p15", name: "iPhone 15", price: 18000, daily: 812, days: 360 },
];
app.get("/products", (req, res) => res.json(products));

app.post("/invest", auth, (req, res) => {
  const { productId } = req.body;
  const user = db.users.find((u) => u.id === req.user.id);
  const prod = products.find((p) => p.id === productId);
  if (!prod) return res.status(400).json({ error: "Invalid product" });
  if (user.balance < prod.price) return res.status(400).json({ error: "Insufficient" });

  user.balance -= prod.price;
  user.investments.push({
    id: generateId("inv"),
    productId: prod.id,
    daily: prod.daily,
    remaining: prod.days,
    created: Date.now(),
  });
  db.transactions.push({
    id: generateId("t"),
    type: "investment",
    userId: user.id,
    amount: prod.price,
    date: Date.now(),
  });
  saveDB(db);
  res.json({ success: true });
});

// ---------------- Wallet ----------------
app.get("/me", auth, (req, res) => {
  const user = db.users.find((u) => u.id === req.user.id);
  res.json(user);
});

app.post("/deposit", auth, (req, res) => {
  const { amount } = req.body;
  const dep = {
    id: generateId("d"),
    userId: req.user.id,
    amount,
    status: "pending",
    date: Date.now(),
  };
  db.deposits.push(dep);
  saveDB(db);
  res.json({ success: true, dep });
});

app.post("/withdraw", auth, (req, res) => {
  const { amount } = req.body;
  const user = db.users.find((u) => u.id === req.user.id);
  if (user.balance < amount) return res.status(400).json({ error: "Insufficient" });
  const wd = {
    id: generateId("w"),
    userId: user.id,
    amount,
    status: "pending",
    date: Date.now(),
  };
  db.withdrawals.push(wd);
  saveDB(db);
  res.json({ success: true, wd });
});

// ---------------- Cron Jobs ----------------
cron.schedule("0 0 * * *", () => {
  db.users.forEach((u) => {
    u.investments.forEach((inv) => {
      if (inv.remaining > 0) {
        u.balance += inv.daily;
        inv.remaining -= 1;
        db.transactions.push({
          id: generateId("t"),
          type: "payout",
          userId: u.id,
          amount: inv.daily,
          date: Date.now(),
        });
      }
    });
  });
  saveDB(db);
  console.log("Daily payouts done");
});

// ---------------- Frontend ----------------
app.get("/", (req, res) => {
  res.send(`
<!DOCTYPE html>
<html>
<head>
  <title>Money Pool</title>
</head>
<body>
  <h1>Welcome to Money Pool</h1>
  <p>Sign up, login, invest, and earn!</p>
  <script>
    async function claim() {
      const token = localStorage.getItem("token");
      const res = await fetch("/me", { headers: { "Authorization": "Bearer " + token } });
      const user = await res.json();
      alert("Your balance: " + user.balance);
    }
  </script>
  <button onclick="claim()">Check Balance</button>
</body>
</html>
  `);
});

// ---------------- Start ----------------
app.listen(PORT, () => console.log("Server running on " + PORT));
